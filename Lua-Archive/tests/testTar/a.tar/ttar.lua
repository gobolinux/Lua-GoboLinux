#!/bin/lua

-- vi: set foldmethod=marker foldlevel=0:
--
-- test.lua
-- ---------------------------------------------------------------------------
--  - 2007
-- ---------------------------------------------------------------------------
-- Author: Aitor Pérez Iturri - <aitor.iturri@gmail.com>	
-- Created: 14/11/07 14:29:47 CET
-- License: GNU GPL (see www.fsf.org for details)
-- ---------------------------------------------------------------------------
-- Description:
--
-- ---------------------------------------------------------------------------

package.cpath="../../.libs/?.so;"..package.cpath

require "tar"
require "posix"
require "GoboLinux.OptionParser"
require "GoboLinux.output"

local output = GoboLinux.output

local luatar = GoboLinux.OptionParser.new()

luatar.Program = "luaTar"
luatar.Version = "1.0"
luatar.Credits = "Aitor Pérez Iturri - GNU GPL"
luatar.Description = "Little implementation of tar command in lua"
luatar.Example = "luaTar -z -x -f foo.tar -C /tmp"
luatar:addEntry("t","list", "List tar contents")
luatar:addEntry("x","extract", "Extract tar contents")
luatar:addEntry("f","file", "Use specific tar file")
luatar:addEntry("c","create", "Create a new specific tar file")
luatar:addEntry("z","gzip", "Uses gzip to compress or decompress the tar file")
luatar:addEntry("j","bzip2", "Uses bzip2 to compress or decompress the tar file")
luatar:addEntry("C",nil,"Changes to dir before to do the work")

local function luatar_list (file, compression)
	local fd, err = tar.open(file,"r", compression)
	if not fd then
		output.log_error("Error luatar_list: "..err)
		return false
	end
	local entry = fd:read()
	while entry do
		output.log_terse(entry, 2);
		entry = fd:read()
	end
	fd:close()
end

local function main (argc, argv)
	local success
	if argc == 0 then
		luatar:usage()
	end
	luatar:parseOptions(argv)
	print("KKK")
	-- Gets tar file
	local tarfile = lutar:isEntry("f")
	if not tarfile then
		luatar:usage()
	end

	-- Gets arguments
	local arguments = luatar:arguments()

	-- Gets compression mode
	local compression
	if luatar:isEntry("z") then
		compression="gzip"
	elseif luatar:isEntry("j") then
		compression="bzip2"
	else
		compression="none"
	end

	-- Gets operation requested
	if (luatar:isEntry("t")) then
		print("kkkkkkk")
		success = luatar_list(tarfile, compression)
	elseif luatar:isEntry("c") then
		if not arguments then 
			luatar:usage()
		end
		success = luatar_create(tarfile, compression, arguments[1])
	elseif luatar:isEntry("x") then
		local path = luatar:isEntry("C")
		success = luatar_extract(tarfile, compression, path or ".")
	end
	return success
end

main(#arg, arg)
